<?php
$link = mysqli_connect($_SERVER['aaeldfalnt6o43.csljttxtmtng.us-west-2.rds.amazonaws.com'], $_SERVER['will42'], 
$_SERVER['!pa55W0rD'], $_SERVER['aaeldfalnt6o43'], $_SERVER['3306']);

?>