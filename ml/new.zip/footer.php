<div class="bg-primary text-center">
<ul class="nav justify-content-center">
  <li class="nav-item">
    <a class="nav-link" style="color:black" href="#">About</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" style="color:black" href="#">Contact</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" style="color:black" href="#">Help Center</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" style="color:black" href="#">FAQs</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" style="color:black" href="#">Languages</a>
  </li>
</ul>
</div>
